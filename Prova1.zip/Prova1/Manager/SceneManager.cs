﻿﻿#region using
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova1.Objects;
using Prova1.View;
#endregion

namespace Prova1.Manager
{
    static class SceneManager
    {
        #region private
        static List<Scene> scenes;
        static Scene actualScene;
        static Screen screen;
        static Camera actualCamera;
        #endregion

        #region public
        public static ContentManager staticContent;
        public static GraphicsDevice staticDevice;
        public static Effect staticEffect;
        #endregion

        public static void Initialize(GraphicsDevice device, ContentManager content, int screenWidth, int screenHeight)
        {
            staticDevice = device;
            staticContent = content;

            screen = Screen.GetInstance();
            screen.SetWidth(screenWidth);
            screen.SetHeight(screenHeight);

            actualCamera = new CameraFree();
            actualCamera.SetPosition(Vector3.Backward * 7);
        }

        public static void LoadContent(ContentManager content)
        {
            Obj f = new Obj(new List<Quad>
                                           {
                                                   #region
                                               new Quad(new Vector3(0.32f,0.68f,-0.00f),
new Vector3(0.32f,0.59f,-0.00f),
new Vector3(0.05f,0.59f,-0.00f),
new Vector3(-0.04f,0.68f,-0.00f)
,Color.Red),

new Quad(new Vector3(0.32f,0.41f,-0.00f),
new Vector3(0.32f,0.32f,-0.00f),
new Vector3(0.05f,0.32f,-0.00f),
new Vector3(0.05f,0.41f,-0.00f)
,Color.Red),

new Quad(new Vector3(0.05f,0.41f,-0.00f),
new Vector3(0.05f,0.32f,-0.00f),
new Vector3(0.05f,0.32f,-0.24f),
new Vector3(0.05f,0.41f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.00f,-0.00f),
new Vector3(0.05f,0.59f,-0.00f),
new Vector3(0.05f,0.59f,-0.24f),
new Vector3(0.05f,0.00f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.59f,-0.00f),
new Vector3(0.32f,0.59f,-0.00f),
new Vector3(0.32f,0.59f,-0.24f),
new Vector3(0.05f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.32f,0.41f,-0.24f),
new Vector3(0.05f,0.41f,-0.24f),
new Vector3(0.05f,0.32f,-0.24f),
new Vector3(0.32f,0.32f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.32f,-0.00f),
new Vector3(0.32f,0.32f,-0.00f),
new Vector3(0.32f,0.32f,-0.24f),
new Vector3(0.05f,0.32f,-0.24f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.00f,-0.00f),
new Vector3(0.05f,0.00f,-0.00f),
new Vector3(0.05f,0.00f,-0.24f),
new Vector3(-0.04f,0.00f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.00f,-0.00f),
new Vector3(-0.04f,0.00f,-0.00f),
new Vector3(-0.04f,0.00f,-0.24f),
new Vector3(0.05f,0.00f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.32f,0.41f,-0.00f),
new Vector3(0.05f,0.41f,-0.00f),
new Vector3(0.05f,0.41f,-0.24f),
new Vector3(0.32f,0.41f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.32f,0.59f,-0.00f),
new Vector3(0.32f,0.68f,-0.00f),
new Vector3(0.32f,0.68f,-0.24f),
new Vector3(0.32f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.68f,-0.00f),
new Vector3(-0.04f,0.00f,-0.00f),
new Vector3(-0.04f,0.00f,-0.24f),
new Vector3(-0.04f,0.68f,-0.24f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.00f,-0.00f),
new Vector3(-0.04f,0.68f,-0.00f),
new Vector3(-0.04f,0.68f,-0.24f),
new Vector3(-0.04f,0.00f,-0.24f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.68f,-0.24f),
new Vector3(-0.04f,0.00f,-0.24f),
new Vector3(0.05f,0.00f,-0.24f),
new Vector3(0.05f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.32f,0.68f,-0.24f),
new Vector3(-0.04f,0.68f,-0.24f),
new Vector3(0.05f,0.59f,-0.24f),
new Vector3(0.32f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.68f,-0.00f),
new Vector3(0.05f,0.59f,-0.00f),
new Vector3(0.05f,0.00f,-0.00f),
new Vector3(-0.04f,0.00f,-0.00f)
,Color.Red),

new Quad(new Vector3(0.32f,0.68f,-0.00f),
new Vector3(-0.04f,0.68f,-0.00f),
new Vector3(-0.04f,0.68f,-0.24f),
new Vector3(0.32f,0.68f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.32f,-0.00f),
new Vector3(0.05f,0.00f,-0.00f),
new Vector3(0.05f,0.00f,-0.24f),
new Vector3(0.05f,0.32f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.59f,-0.00f),
new Vector3(0.05f,0.41f,-0.00f),
new Vector3(0.05f,0.41f,-0.24f),
new Vector3(0.05f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.05f,0.59f,-0.00f),
new Vector3(-0.04f,0.68f,-0.00f),
new Vector3(-0.04f,0.68f,-0.24f),
new Vector3(0.05f,0.59f,-0.24f)
,Color.Red),

new Quad(new Vector3(0.32f,0.32f,-0.00f),
new Vector3(0.32f,0.41f,-0.00f),
new Vector3(0.32f,0.41f,-0.24f),
new Vector3(0.32f,0.32f,-0.24f)
,Color.Red),
                                                   #endregion
                                           });

            Obj e = new Obj(new List<Quad>
                                           {
                                                   #region
                                               new Quad(new Vector3(0.20f,0.09f,0.12f),
new Vector3(0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,0.12f),
new Vector3(0.19f,0.59f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.20f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,0.12f),
new Vector3(0.18f,0.30f,0.12f),
new Vector3(-0.10f,0.30f,0.12f),
new Vector3(-0.10f,0.39f,0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(0.19f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,-0.12f),
new Vector3(-0.10f,0.39f,-0.12f),
new Vector3(-0.10f,0.30f,-0.12f),
new Vector3(0.18f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(0.20f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.00f,0.12f),
new Vector3(0.20f,0.09f,0.12f),
new Vector3(0.20f,0.09f,-0.12f),
new Vector3(0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.30f,0.12f),
new Vector3(0.18f,0.39f,0.12f),
new Vector3(0.18f,0.39f,-0.12f),
new Vector3(0.18f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.59f,0.12f),
new Vector3(0.19f,0.59f,0.12f),
new Vector3(0.19f,0.59f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,0.12f),
new Vector3(-0.10f,0.39f,0.12f),
new Vector3(-0.10f,0.39f,-0.12f),
new Vector3(0.18f,0.39f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(0.19f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.30f,0.12f),
new Vector3(0.18f,0.30f,0.12f),
new Vector3(0.18f,0.30f,-0.12f),
new Vector3(-0.10f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.39f,0.12f),
new Vector3(-0.10f,0.30f,0.12f),
new Vector3(-0.10f,0.30f,-0.12f),
new Vector3(-0.10f,0.39f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(0.20f,0.00f,0.12f),
new Vector3(0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.59f,0.12f),
new Vector3(0.19f,0.68f,0.12f),
new Vector3(0.19f,0.68f,-0.12f),
new Vector3(0.19f,0.59f,-0.12f)
,Color.Red),
                                                   #endregion
                                           });

            Obj l = new Obj(new List<Quad>
                                           {
                                                   #region
                                               new Quad(new Vector3(0.21f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(0.21f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.09f,-0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(0.21f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.10f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,0.12f),
new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.00f,0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(0.21f,0.09f,-0.12f),
new Vector3(0.21f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.09f,0.12f),
new Vector3(0.21f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),


                                                   #endregion
                                           });

            Obj ll = new Obj(new List<Quad> {
            #region
                                               new Quad(new Vector3(0.21f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(0.21f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.09f,-0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(0.21f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.10f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.68f,0.12f),
new Vector3(-0.10f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.00f,0.12f),
new Vector3(0.21f,0.00f,-0.12f),
new Vector3(0.21f,0.09f,-0.12f),
new Vector3(0.21f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.09f,0.12f),
new Vector3(0.21f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),


                                                   #endregion
            });

            Obj i = new Obj(new List<Quad>
                                           {
                                                   #region
                                               new Quad(new Vector3(0.05f,0.68f,0.12f),
new Vector3(-0.04f,0.68f,0.12f),
new Vector3(-0.04f,0.00f,0.12f),
new Vector3(0.05f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.68f,-0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(-0.04f,0.00f,-0.12f),
new Vector3(-0.04f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.00f,0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(0.05f,0.68f,-0.12f),
new Vector3(0.05f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.00f,0.12f),
new Vector3(-0.04f,0.00f,-0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(0.05f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.04f,0.68f,0.12f),
new Vector3(-0.04f,0.68f,-0.12f),
new Vector3(-0.04f,0.00f,-0.12f),
new Vector3(-0.04f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.68f,0.12f),
new Vector3(0.05f,0.68f,-0.12f),
new Vector3(-0.04f,0.68f,-0.12f),
new Vector3(-0.04f,0.68f,0.12f)
,Color.Red),


                                                   #endregion
                                           });

            Obj p = new Obj(new List<Quad>
                                           {
                                                   #region
                                               new Quad(new Vector3(0.05f,0.59f,0.12f),
new Vector3(-0.05f,0.68f,0.12f),
new Vector3(-0.05f,0.00f,0.12f),
new Vector3(0.05f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.05f,0.68f,0.12f),
new Vector3(0.05f,0.59f,0.12f),
new Vector3(0.12f,0.60f,0.12f),
new Vector3(0.06f,0.72f,0.12f)
,Color.Red),

new Quad(new Vector3(0.06f,0.72f,0.12f),
new Vector3(0.12f,0.60f,0.12f),
new Vector3(0.17f,0.58f,0.12f),
new Vector3(0.18f,0.71f,0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.71f,0.12f),
new Vector3(0.17f,0.58f,0.12f),
new Vector3(0.22f,0.54f,0.12f),
new Vector3(0.28f,0.65f,0.12f)
,Color.Red),

new Quad(new Vector3(0.28f,0.65f,0.12f),
new Vector3(0.22f,0.54f,0.12f),
new Vector3(0.24f,0.48f,0.12f),
new Vector3(0.34f,0.56f,0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.56f,0.12f),
new Vector3(0.24f,0.48f,0.12f),
new Vector3(0.24f,0.41f,0.12f),
new Vector3(0.37f,0.45f,0.12f)
,Color.Red),

new Quad(new Vector3(0.37f,0.45f,0.12f),
new Vector3(0.24f,0.41f,0.12f),
new Vector3(0.21f,0.36f,0.12f),
new Vector3(0.34f,0.34f,0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.34f,0.12f),
new Vector3(0.21f,0.36f,0.12f),
new Vector3(0.16f,0.32f,0.12f),
new Vector3(0.27f,0.25f,0.12f)
,Color.Red),

new Quad(new Vector3(0.27f,0.25f,0.12f),
new Vector3(0.16f,0.32f,0.12f),
new Vector3(0.10f,0.31f,0.12f),
new Vector3(0.17f,0.19f,0.12f)
,Color.Red),

new Quad(new Vector3(0.17f,0.19f,0.12f),
new Vector3(0.10f,0.31f,0.12f),
new Vector3(0.04f,0.32f,0.12f),
new Vector3(0.05f,0.19f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.59f,-0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(-0.05f,0.00f,-0.12f),
new Vector3(-0.05f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.05f,0.68f,-0.12f),
new Vector3(0.06f,0.72f,-0.12f),
new Vector3(0.12f,0.60f,-0.12f),
new Vector3(0.05f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.06f,0.72f,-0.12f),
new Vector3(0.18f,0.71f,-0.12f),
new Vector3(0.17f,0.58f,-0.12f),
new Vector3(0.12f,0.60f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.71f,-0.12f),
new Vector3(0.28f,0.65f,-0.12f),
new Vector3(0.22f,0.54f,-0.12f),
new Vector3(0.17f,0.58f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.28f,0.65f,-0.12f),
new Vector3(0.34f,0.56f,-0.12f),
new Vector3(0.24f,0.48f,-0.12f),
new Vector3(0.22f,0.54f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.56f,-0.12f),
new Vector3(0.37f,0.45f,-0.12f),
new Vector3(0.24f,0.41f,-0.12f),
new Vector3(0.24f,0.48f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.37f,0.45f,-0.12f),
new Vector3(0.34f,0.34f,-0.12f),
new Vector3(0.21f,0.36f,-0.12f),
new Vector3(0.24f,0.41f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.34f,-0.12f),
new Vector3(0.27f,0.25f,-0.12f),
new Vector3(0.16f,0.32f,-0.12f),
new Vector3(0.21f,0.36f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.27f,0.25f,-0.12f),
new Vector3(0.17f,0.19f,-0.12f),
new Vector3(0.10f,0.31f,-0.12f),
new Vector3(0.16f,0.32f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.17f,0.19f,-0.12f),
new Vector3(0.05f,0.19f,-0.12f),
new Vector3(0.04f,0.32f,-0.12f),
new Vector3(0.10f,0.31f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.27f,0.25f,0.12f),
new Vector3(0.27f,0.25f,-0.12f),
new Vector3(0.34f,0.34f,-0.12f),
new Vector3(0.34f,0.34f,0.12f)
,Color.Red),

new Quad(new Vector3(0.17f,0.19f,0.12f),
new Vector3(0.17f,0.19f,-0.12f),
new Vector3(0.27f,0.25f,-0.12f),
new Vector3(0.27f,0.25f,0.12f)
,Color.Red),

new Quad(new Vector3(0.16f,0.32f,0.12f),
new Vector3(0.16f,0.32f,-0.12f),
new Vector3(0.10f,0.31f,-0.12f),
new Vector3(0.10f,0.31f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.05f,0.68f,0.12f),
new Vector3(-0.05f,0.68f,-0.12f),
new Vector3(-0.05f,0.00f,-0.12f),
new Vector3(-0.05f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.59f,0.12f),
new Vector3(0.05f,0.59f,-0.12f),
new Vector3(0.12f,0.60f,-0.12f),
new Vector3(0.12f,0.60f,0.12f)
,Color.Red),

new Quad(new Vector3(-0.05f,0.00f,0.12f),
new Vector3(-0.05f,0.00f,-0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(0.05f,0.00f,0.12f)
,Color.Red),

new Quad(new Vector3(0.04f,0.32f,0.12f),
new Vector3(0.04f,0.32f,-0.12f),
new Vector3(0.05f,0.19f,-0.12f),
new Vector3(0.05f,0.19f,0.12f)
,Color.Red),

new Quad(new Vector3(0.10f,0.31f,0.12f),
new Vector3(0.10f,0.31f,-0.12f),
new Vector3(0.04f,0.32f,-0.12f),
new Vector3(0.04f,0.32f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.19f,0.12f),
new Vector3(0.05f,0.19f,-0.12f),
new Vector3(0.17f,0.19f,-0.12f),
new Vector3(0.17f,0.19f,0.12f)
,Color.Red),

new Quad(new Vector3(0.06f,0.72f,0.12f),
new Vector3(0.06f,0.72f,-0.12f),
new Vector3(-0.05f,0.68f,-0.12f),
new Vector3(-0.05f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.71f,0.12f),
new Vector3(0.18f,0.71f,-0.12f),
new Vector3(0.06f,0.72f,-0.12f),
new Vector3(0.06f,0.72f,0.12f)
,Color.Red),

new Quad(new Vector3(0.12f,0.60f,0.12f),
new Vector3(0.12f,0.60f,-0.12f),
new Vector3(0.17f,0.58f,-0.12f),
new Vector3(0.17f,0.58f,0.12f)
,Color.Red),

new Quad(new Vector3(0.28f,0.65f,0.12f),
new Vector3(0.28f,0.65f,-0.12f),
new Vector3(0.18f,0.71f,-0.12f),
new Vector3(0.18f,0.71f,0.12f)
,Color.Red),

new Quad(new Vector3(0.17f,0.58f,0.12f),
new Vector3(0.17f,0.58f,-0.12f),
new Vector3(0.22f,0.54f,-0.12f),
new Vector3(0.22f,0.54f,0.12f)
,Color.Red),

new Quad(new Vector3(0.22f,0.54f,0.12f),
new Vector3(0.22f,0.54f,-0.12f),
new Vector3(0.24f,0.48f,-0.12f),
new Vector3(0.24f,0.48f,0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.56f,0.12f),
new Vector3(0.34f,0.56f,-0.12f),
new Vector3(0.28f,0.65f,-0.12f),
new Vector3(0.28f,0.65f,0.12f)
,Color.Red),

new Quad(new Vector3(0.37f,0.45f,0.12f),
new Vector3(0.37f,0.45f,-0.12f),
new Vector3(0.34f,0.56f,-0.12f),
new Vector3(0.34f,0.56f,0.12f)
,Color.Red),

new Quad(new Vector3(0.24f,0.48f,0.12f),
new Vector3(0.24f,0.48f,-0.12f),
new Vector3(0.24f,0.41f,-0.12f),
new Vector3(0.24f,0.41f,0.12f)
,Color.Red),

new Quad(new Vector3(0.24f,0.41f,0.12f),
new Vector3(0.24f,0.41f,-0.12f),
new Vector3(0.21f,0.36f,-0.12f),
new Vector3(0.21f,0.36f,0.12f)
,Color.Red),

new Quad(new Vector3(0.34f,0.34f,0.12f),
new Vector3(0.34f,0.34f,-0.12f),
new Vector3(0.37f,0.45f,-0.12f),
new Vector3(0.37f,0.45f,0.12f)
,Color.Red),

new Quad(new Vector3(0.05f,0.00f,0.12f),
new Vector3(0.05f,0.00f,-0.12f),
new Vector3(0.05f,0.59f,-0.12f),
new Vector3(0.05f,0.59f,0.12f)
,Color.Red),

new Quad(new Vector3(0.21f,0.36f,0.12f),
new Vector3(0.21f,0.36f,-0.12f),
new Vector3(0.16f,0.32f,-0.12f),
new Vector3(0.16f,0.32f,0.12f)
,Color.Red),


                                                   #endregion
                                           });

            Obj ee = new Obj(new List<Quad> { 
            #region
                                               new Quad(new Vector3(0.20f,0.09f,0.12f),
new Vector3(0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,0.12f),
new Vector3(0.19f,0.59f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.20f,0.68f,0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,0.12f),
new Vector3(0.18f,0.30f,0.12f),
new Vector3(-0.10f,0.30f,0.12f),
new Vector3(-0.10f,0.39f,0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.09f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.10f,0.09f,0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(0.19f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,-0.12f),
new Vector3(-0.10f,0.39f,-0.12f),
new Vector3(-0.10f,0.30f,-0.12f),
new Vector3(0.18f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.09f,-0.12f),
new Vector3(0.20f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.20f,0.00f,0.12f),
new Vector3(0.20f,0.09f,0.12f),
new Vector3(0.20f,0.09f,-0.12f),
new Vector3(0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.00f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.30f,0.12f),
new Vector3(0.18f,0.39f,0.12f),
new Vector3(0.18f,0.39f,-0.12f),
new Vector3(0.18f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.59f,0.12f),
new Vector3(0.19f,0.59f,0.12f),
new Vector3(0.19f,0.59f,-0.12f),
new Vector3(-0.10f,0.59f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.18f,0.39f,0.12f),
new Vector3(-0.10f,0.39f,0.12f),
new Vector3(-0.10f,0.39f,-0.12f),
new Vector3(0.18f,0.39f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,0.12f),
new Vector3(-0.20f,0.68f,-0.12f),
new Vector3(0.19f,0.68f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.30f,0.12f),
new Vector3(0.18f,0.30f,0.12f),
new Vector3(0.18f,0.30f,-0.12f),
new Vector3(-0.10f,0.30f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.09f,0.12f),
new Vector3(-0.10f,0.59f,0.12f),
new Vector3(-0.10f,0.59f,-0.12f),
new Vector3(-0.10f,0.09f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.10f,0.39f,0.12f),
new Vector3(-0.10f,0.30f,0.12f),
new Vector3(-0.10f,0.30f,-0.12f),
new Vector3(-0.10f,0.39f,-0.12f)
,Color.Red),

new Quad(new Vector3(-0.20f,0.00f,0.12f),
new Vector3(0.20f,0.00f,0.12f),
new Vector3(0.20f,0.00f,-0.12f),
new Vector3(-0.20f,0.00f,-0.12f)
,Color.Red),

new Quad(new Vector3(0.19f,0.59f,0.12f),
new Vector3(0.19f,0.68f,0.12f),
new Vector3(0.19f,0.68f,-0.12f),
new Vector3(0.19f,0.59f,-0.12f)
,Color.Red),
                                                   #endregion
            });

            Obj name = new Obj();

            float factor = 3.5f;

            f.SetPosition(Vector3.Left * factor--);
            e.SetPosition(Vector3.Left * factor--);
            l.SetPosition(Vector3.Left * factor--);
            ll.SetPosition(Vector3.Left * factor--);
            i.SetPosition(Vector3.Left * factor--);
            p.SetPosition(Vector3.Left * factor--);
            ee.SetPosition(Vector3.Left * factor--);

            //TODO: Create sets
            //TODO: Include objects on set
            List<Obj> sceneSet = new List<Obj> 
            {
                f,
                e,
                l,
                ll,
                i,
                p,
                ee
            };

            //TODO: Create scenes
            //TODO: Insert the set of objects on scene
            actualScene = new Scene(sceneSet, "Cena 1");

            //TODO: add the scences
            scenes = new List<Scene>();
            scenes.Add(actualScene);
        }

        public static void Update(GameTime gameTime)
        {
            //TODO: Logic to update a scene
            actualCamera.Update(gameTime);
            actualScene.Update(gameTime);
        }

        public static void Draw()
        {
            //TODO: Logic to draw a scene
            actualScene.Draw(actualCamera);
        }

        public static Scene GetActualScene()
        {
            return actualScene;
        }
    }
}
